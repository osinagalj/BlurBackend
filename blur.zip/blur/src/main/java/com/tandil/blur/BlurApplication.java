package com.tandil.blur;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlurApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlurApplication.class, args);
	}

}
