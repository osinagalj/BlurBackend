package com.tandil.blur;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlurApplicationTests {

	@Test
	void contextLoads() {
	}

}
